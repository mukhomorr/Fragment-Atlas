import Indigo from './vendor/indigo/indigo.mjs';

const images=new Map();
let engine;

async function initializeIndigo() {
  const embedded=document.getElementById('indigo-offline');
  if (!embedded) return Indigo();
  const bytes=Uint8Array.from(atob(embedded.textContent.trim()),character=>character.charCodeAt(0));
  const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
  return Indigo({wasmBinary:new Uint8Array(await new Response(stream).arrayBuffer())});
}

async function renderInchi(inchi) {
  if (inchi.length>32000 || !/^InChI=1S?\//.test(inchi)) throw Error('Invalid InChI');
  engine ||= initializeIndigo();
  const indigo=await engine;
  const options=new indigo.MapStringString();
  try {
    options.set('render-output-format','svg');
    const base64=indigo.render(inchi,options);
    if (!base64 || !/^[a-z0-9+/=]+$/i.test(base64)) throw Error('Empty structure');
    return `data:image/svg+xml;base64,${base64}`;
  } finally {
    options.delete();
  }
}

export function showInchiStructure(container,inchi) {
  container.textContent='Rendering structure…';
  if (!images.has(inchi)) {
    if (images.size>=40) images.delete(images.keys().next().value);
    images.set(inchi,renderInchi(inchi));
  }
  images.get(inchi).then(src=>{
    if (!container.isConnected) return;
    const img=document.createElement('img');
    img.alt='2D chemical structure from InChI';
    img.src=src;
    container.replaceChildren(img);
  },()=>{
    if (container.isConnected) container.textContent='Structure could not be rendered from this InChI.';
  });
}
