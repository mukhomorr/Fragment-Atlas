#!/usr/bin/env python3
"""Bundle the static Fragment Atlas source into one offline HTML file."""

import argparse
import base64
import gzip
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
MODULES = ('data.mjs', 'layout.mjs', 'demo.mjs', 'workspace.mjs', 'depiction.mjs', 'app.js')
ENTRY_TAGS = '<link rel="stylesheet" href="style.css"><script type="module" src="app.js"></script>'


def text_file(name):
    return (ROOT / name).read_text(encoding='utf-8')


def offline_script(indigo):
    if indigo.count('export default Module;') != 1:
        raise ValueError('The Indigo module wrapper changed.')
    indigo = indigo.replace('export default Module;', 'return Module;')
    indigo = indigo.replace('import.meta.url', 'document.baseURI')
    bundle = ['(() => {', '"use strict";', 'const Indigo = (() => {', indigo, '})();']
    for name in MODULES:
        source = text_file(name)
        symbols = ', '.join(re.findall(r'^export (?:function|const) (\w+)', source, re.M))
        source = re.sub(r'^import .*;\n', '', source, flags=re.M)
        source = re.sub(r'^export (?=function |const )', '', source, flags=re.M)
        if re.search(r'^\s*(?:export|import)\s', source, re.M):
            raise ValueError(f'Unsupported module syntax in {name}.')
        bundle.append(f'const {{ {symbols} }} = (() => {{' if symbols else '(() => {')
        bundle.append(source)
        if symbols:
            bundle.append(f'return {{ {symbols} }};')
        bundle.append('})();')
    bundle.append('})();')
    script = '\n'.join(bundle)
    if '</script' in script.lower():
        raise ValueError('Bundled JavaScript contains an HTML script end tag.')
    return script


def build(output):
    html = text_file('index.html')
    if html.count(ENTRY_TAGS) != 1 or html.count('</body>') != 1:
        raise ValueError('The entry tags in index.html changed.')
    vendor = ROOT / 'vendor' / 'indigo'
    wasm, = vendor.glob('*.wasm')
    payload = base64.b64encode(gzip.compress(wasm.read_bytes(), mtime=0)).decode('ascii')
    license_text = (vendor / 'LICENSE').read_text(encoding='utf-8')
    if '-->' in license_text:
        raise ValueError('The vendor license contains an HTML comment end tag.')
    embedded = (
        f'<!-- Indigo third-party license\n{license_text}\n-->\n'
        f'<script type="application/octet-stream" id="indigo-offline">{payload}</script>'
    )
    script = offline_script(text_file('vendor/indigo/indigo.mjs'))
    html = html.replace(ENTRY_TAGS, f'<style>\n{text_file("style.css")}\n</style>')
    html = html.replace('</body>', f'{embedded}\n<script>\n{script}\n</script>\n</body>')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html, encoding='utf-8')
    print(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'build' / 'fragment-atlas-v0.33.html')
    build(parser.parse_args().output)
