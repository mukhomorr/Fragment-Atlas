// Fabricated data that exercises spectrum linking, shifts, and annotations.
const nodes = [
  {id:101,name:'Ethanol',mz:47.04914,rt:1.20,group:'Example A',inchi:'InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3',peaks:[[19.018,20],[27.023,35],[31.018,100],[45.033,66]]},
  {id:102,name:'1-Propanol',mz:61.06479,rt:1.46,group:'Example A',inchi:'InChI=1S/C3H8O/c1-2-3-4/h4H,2-3H2,1H3',peaks:[[19.018,18],[27.023,32],[45.034,100],[59.049,63]]},
  {id:103,name:'Example feature 103',mz:75.08044,rt:1.89,group:'Example A',peaks:[[27.023,40],[41.039,31],[59.049,100],[73.064,61]]},
  {id:104,name:'Example feature 104',mz:89.09609,rt:2.42,group:'Example A',peaks:[[41.039,36],[55.054,26],[73.064,100],[87.080,61]]},
  {id:201,name:'Example feature 201',mz:123.04406,rt:3.01,group:'Example B',peaks:[[51.023,26],[65.039,42],[79.054,100],[95.049,71]]},
  {id:202,name:'Example feature 202',mz:137.05971,rt:3.15,group:'Example B',peaks:[[51.023,24],[65.039,40],[93.070,100],[109.065,69]]},
  {id:203,name:'Example feature 203',mz:151.07536,rt:3.39,group:'Example B',peaks:[[65.039,41],[79.054,21],[107.085,100],[123.080,65]]}
];
const links = [[101,102],[102,103],[103,104],[101,103],[201,202],[202,203]];
const fields = [
  ['name','Compound name','string',node=>node.name],
  ['mass','parent mass','double',node=>node.mz],
  ['rt','Retention time (min)','double',node=>node.rt],
  ['charge','precursor charge','int',()=>1],
  ['group','Sample group','string',node=>node.group],
  ['inchi','INCHI','string',node=>node.inchi],
  ['library','LibraryID','string',node=>node.inchi?'Synthetic example':'']
];

export function exampleFiles() {
  const graph = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<graphml xmlns="http://graphml.graphdrawing.org/xmlns">',
    ...fields.map(([id,name,type])=>`<key id="${id}" for="node" attr.name="${name}" attr.type="${type}"/>`),
    '<graph edgedefault="undirected">',
    ...nodes.map(node=>`<node id="${node.id}">${fields.map(([id,,,read])=>{
      const value=read(node);
      return value===undefined || value===''?'':`<data key="${id}">${value}</data>`;
    }).join('')}</node>`),
    ...links.map(([a,b])=>`<edge source="${a}" target="${b}"/>`),
    '</graph></graphml>'
  ].join('\n');
  const spectra = nodes.map(node=>[
    'BEGIN IONS',`SCANS=${node.id}`,`PEPMASS=${node.mz}`,'CHARGE=1+',
    `RTINMINUTES=${node.rt}`,...node.peaks.map(peak=>peak.join(' ')),'END IONS'
  ].join('\n')).join('\n\n');
  return {graph,spectra};
}
