import {graphml,mgf,align,nodeMetadata,nodeColorMap} from './data.mjs';
import {arrangeNetwork} from './layout.mjs';
import {annotateNode,openNodeTable} from './workspace.mjs';
import {showInchiStructure} from './depiction.mjs';
import {exampleFiles} from './demo.mjs';

const $ = id => document.getElementById(id);
const canvas = $('network');
const ctx = canvas.getContext('2d');
const cyan = '#006f77';
const pink = '#7344aa';
let nodes = [], edges = [], byId = new Map(), imported = [];
let first = null, second = null, width = 1, height = 1, view = {x:0,y:0,k:1};
let pointer = null, hover = null, importGeneration = 0;
let usingExampleSpectra=false;
let group = new Set(), boxMode = false;
let colorColumns=[], nodeColors=new Map();

function layout() {
  arrangeNetwork(nodes,edges,canvas.clientWidth/canvas.clientHeight);
}
$('arrange').onclick=()=>{
  layout();
  fit();
};

function draw() {
  ctx.clearRect(0,0,width,height);
  ctx.save();
  ctx.translate(view.x,view.y);
  ctx.scale(view.k,view.k);
  ctx.lineWidth = 1/view.k;
  ctx.strokeStyle = '#657c9952';
  ctx.beginPath();
  for (const [a,b] of edges) {
    ctx.moveTo(a.x,a.y);
    ctx.lineTo(b.x,b.y);
  }
  ctx.stroke();
  if (first && second && edges.some(([a,b]) => (a===first && b===second)||(a===second && b===first))) {
    ctx.strokeStyle = cyan;
    ctx.lineWidth = 2/view.k;
    ctx.beginPath();
    ctx.moveTo(first.x,first.y);
    ctx.lineTo(second.x,second.y);
    ctx.stroke();
  }
  const nodeRadius=Math.max(1.4,Math.min(4.8,view.k*17));
  for (const node of nodes) {
    const selected = node===first || node===second || node===hover;
    const color = node===first ? cyan : node===second ? pink : node.color;
    ctx.beginPath();
    ctx.fillStyle = nodeColors.get(node) || color;
    ctx.arc(node.x,node.y,(selected ? 6.7 : nodeRadius)/view.k,0,Math.PI*2);
    ctx.fill();
    if (group.has(node)) {
      ctx.beginPath();
      ctx.arc(node.x,node.y,selected?13/view.k:9/view.k,0,Math.PI*2);
      ctx.strokeStyle='#a05b08';
      ctx.lineWidth=2/view.k;
      ctx.stroke();
    }
    if (!selected) continue;
    ctx.beginPath();
    ctx.arc(node.x,node.y,10/view.k,0,Math.PI*2);
    ctx.strokeStyle = color;
    ctx.lineWidth = 1/view.k;
    ctx.stroke();
  }
  ctx.restore();
  drawLabels();
  if (pointer?.box) {
    const {x,y,left,top}=pointer.box;
    ctx.fillStyle='#00778328';
    ctx.strokeStyle=cyan;
    ctx.lineWidth=1;
    ctx.fillRect(left,top,x-left,y-top);
    ctx.strokeRect(left,top,x-left,y-top);
  }
}
function nodeCaption(node, field) {
  if (field==='mass') {
    const mass=node.spectrum?.precursor ?? node.precursor;
    return Number.isFinite(mass)?mass.toFixed(4):'';
  }
  if (field==='name') return node.label;
  if (field.startsWith('graph:')) return node.fields?.get(field.slice(6)) || '';
  if (field.startsWith('mgf:')) return node.spectrum?.metadata?.[field.slice(4)] || '';
  return node.id;
}
function drawLabels() {
  const field=$('nodeLabel').value;
  const selected=new Set([first,second,hover].filter(Boolean));
  const candidates=field ? [...selected,...nodes.filter(node=>!selected.has(node))] : selected;
  const occupied=new Set();
  ctx.font='650 12px system-ui';
  ctx.lineWidth=3.5;
  ctx.lineJoin='round';
  ctx.strokeStyle='#f9fbfd';
  for (const node of candidates) {
    const x=node.x*view.k+view.x+12;
    const y=node.y*view.k+view.y-8;
    if (x<0 || x>width || y<12 || y>height) continue;
    const active=selected.has(node);
    const value=nodeCaption(node,field);
    if (!value && !active) continue;
    const full=value || node.id;
    const label=full.length>32?full.slice(0,31)+'…':full;
    const length=ctx.measureText(label).width;
    const row=Math.floor(y/16);
    const cells=[];
    for (let col=Math.floor(x/16);col<=Math.floor((x+length+4)/16);col++) {
      for (let offset=-1;offset<=1;offset++) cells.push(`${row+offset}:${col}`);
    }
    if (!active && cells.some(cell=>occupied.has(cell))) continue;
    cells.forEach(cell=>occupied.add(cell));
    ctx.fillStyle=node===first?cyan:node===second?pink:'#263850';
    ctx.strokeText(label,x,y);
    ctx.fillText(label,x,y);
  }
}
function fit() {
  if (!nodes.length) return;
  let left=Infinity,right=-Infinity,top=Infinity,bottom=-Infinity;
  for (const {x,y} of nodes) {
    left=Math.min(left,x); right=Math.max(right,x); top=Math.min(top,y); bottom=Math.max(bottom,y);
  }
  const k = Math.min(2.4,Math.max(30,width-72)/Math.max(1,right-left),Math.max(30,height-91)/Math.max(1,bottom-top));
  view = {k,x:width/2-(left+right)*k/2,y:(height-25)/2-(top+bottom)*k/2};
  draw();
}
function resize() {
  const previousWidth = width, previousHeight = height;
  width = canvas.clientWidth; height = canvas.clientHeight;
  const pixel = devicePixelRatio || 1;
  canvas.width = Math.round(width*pixel); canvas.height = Math.round(height*pixel);
  ctx.setTransform(pixel,0,0,pixel,0,0);
  if (previousWidth<=1) fit();
  else {
    view.x += (width-previousWidth)/2;
    view.y += (height-previousHeight)/2;
    draw();
  }
}
function zoom(factor,x=width/2,y=height/2) {
  const k = Math.max(.015,Math.min(14,view.k*factor));
  const ratio = k/view.k;
  view = {k,x:x-(x-view.x)*ratio,y:y-(y-view.y)*ratio};
  draw();
}
function hitNode(x,y) {
  let found = null, limit = 12;
  for (const node of nodes) {
    const distance = Math.hypot(node.x*view.k+view.x-x,node.y*view.k+view.y-y);
    if (distance < limit) { found=node; limit=distance; }
  }
  return found;
}
function hitEdge(x,y) {
  let found = null, limit = 7;
  for (const [a,b] of edges) {
    const ax=a.x*view.k+view.x, ay=a.y*view.k+view.y;
    const dx=(b.x-a.x)*view.k, dy=(b.y-a.y)*view.k;
    const length = dx*dx+dy*dy;
    if (!length) continue;
    const t=Math.max(0,Math.min(1,((x-ax)*dx+(y-ay)*dy)/length));
    const distance=Math.hypot(x-ax-t*dx,y-ay-t*dy);
    if (distance<limit) { found=[a,b]; limit=distance; }
  }
  return found;
}
function canvasPoint(event) {
  const bounds=canvas.getBoundingClientRect();
  return {x:event.clientX-bounds.left,y:event.clientY-bounds.top};
}
function updateHover(node) {
  const changed=node!==hover;
  hover=node;
  canvas.style.cursor=boxMode?'crosshair':node?'move':'grab';
  if (changed) draw();
}
canvas.addEventListener('pointerdown',event => {
  if (event.button!==0 || pointer) return;
  const {x,y}=canvasPoint(event);
  const node=boxMode?null:hitNode(x,y);
  canvas.setPointerCapture(event.pointerId);
  const moving=node ? (group.has(node)?[...group]:[node]) : [];
  pointer={
    id:event.pointerId,node,startX:x,startY:y,selecting:!node && (boxMode || event.shiftKey),
    positions:moving.map(member=>({member,x:member.x,y:member.y})),
    originX:view.x,originY:view.y,moved:false
  };
});
canvas.addEventListener('pointermove',event => {
  const {x,y}=canvasPoint(event);
  if (!pointer) {
    updateHover(hitNode(x,y));
    return;
  }
  if (pointer.id!==event.pointerId) return;
  const dx=x-pointer.startX, dy=y-pointer.startY;
  if (!pointer.moved && Math.hypot(dx,dy)<=4) return;
  pointer.moved=true;
  const {node,originX,originY}=pointer;
  if (pointer.selecting) {
    pointer.box=boxBounds(pointer,x,y);
    hover=null;
  } else if (node) {
    for (const position of pointer.positions) {
      position.member.x=position.x+dx/view.k;
      position.member.y=position.y+dy/view.k;
    }
    hover=node;
  } else {
    view.x=originX+dx;
    view.y=originY+dy;
    hover=null;
  }
  canvas.style.cursor=pointer.selecting?'crosshair':'grabbing';
  draw();
});
canvas.addEventListener('pointerleave',() => {
  if (!pointer) updateHover(null);
});
canvas.addEventListener('lostpointercapture',event => {
  if (pointer?.id!==event.pointerId) return;
  pointer=null;
  updateHover(null);
  draw();
});
canvas.addEventListener('pointerup',event => {
  if (pointer?.id!==event.pointerId) return;
  const gesture=pointer;
  pointer=null;
  const {x,y}=canvasPoint(event);
  updateHover(event.pointerType==='touch'?null:hitNode(x,y));
  if (gesture.selecting && gesture.moved) {
    const box=boxBounds(gesture,x,y);
    group=new Set(nodes.filter(node=>{
      const px=node.x*view.k+view.x, py=node.y*view.k+view.y;
      return px>=box.left && px<=box.x && py>=box.top && py<=box.y;
    }));
    setBoxMode(false);
    return;
  }
  if (gesture.moved) return;
  const {node}=gesture;
  if (node) {
    if (event.shiftKey && first && first!==node) select(first,node);
    else select(node,second===node?null:second);
    return;
  }
  const edge=hitEdge(x,y);
  if (edge) select(...edge);
});
canvas.addEventListener('wheel',event => {
  event.preventDefault();
  if (pointer) return;
  const {x,y}=canvasPoint(event);
  zoom(Math.exp(-Math.max(-100,Math.min(100,event.deltaY))*.004),x,y);
},{passive:false});
function boxBounds(gesture,x,y) {
  return {left:Math.min(gesture.startX,x),top:Math.min(gesture.startY,y),x:Math.max(gesture.startX,x),y:Math.max(gesture.startY,y)};
}
function setBoxMode(enabled) {
  boxMode=enabled;
  $('boxSelect').setAttribute('aria-pressed',String(enabled));
  $('clearGroup').hidden=!group.size;
  $('graphHint').textContent=enabled?'Drag a box around nodes':group.size?`${group.size} selected · Drag an outlined node to move the group`:'Drag a node to move it · Click an edge to compare';
  updateHover(hover);
  draw();
}
$('boxSelect').onclick=()=>setBoxMode(!boxMode);
$('clearGroup').onclick=()=>{
  group.clear();
  setBoxMode(false);
};
$('plus').onclick=()=>zoom(1.25);
$('minus').onclick=()=>zoom(.8);
$('fit').onclick=fit;
new ResizeObserver(resize).observe(canvas);

const svgNS='http://www.w3.org/2000/svg';
function graphic(parent,name,attributes,label) {
  const element=document.createElementNS(svgNS,name);
  for (const [key,value] of Object.entries(attributes)) element.setAttribute(key,value);
  if (label!==undefined) element.textContent=label;
  parent.append(element);
  return element;
}
const title = node => node.label===node.id ? `Node ${node.id}` : `${node.label} · ${node.id}`;
let plotState;
let lastPlotWidth;
let mzRange=null, mzScale=null, mzDrag=null, selectedPair=null;
const directColor='#245baf', shiftedColor='#b4283e', unmatchedColor='#8994a3';
const signed=(value, digits=5)=>`${value>0?'+':''}${value.toFixed(digits)}`;
const plotRoot=$('plot');
function plot(a,b,result) {
  if (plotState?.a!==a || plotState?.b!==b) mzRange=null;
  if (plotState?.result!==result) selectedPair=null;
  $('alignmentLegend').hidden=!result;
  showPairReadout(a,b);
  plotState={a,b,result};
  const root=plotRoot;
  root.replaceChildren();
  const chartHeight=Number($('plotHeight').value);
  const chartWidth=Math.max(1,root.clientWidth);
  root.style.setProperty('--plot-height',`${chartHeight}px`);
  lastPlotWidth=chartWidth;
  $('plottitle').textContent=a && b?'Mirror plot':'Fragmentation spectrum';
  if (!a && !b) {
    mzScale=null;
    updateSpectrumButtons();
    const empty=document.createElement('div');
    empty.className='plotempty';
    empty.textContent='Import an MGF file to view fragmentation spectra for nodes without embedded peaks.';
    root.append(empty);
    return;
  }
  const showLabels=$('peakLabels').checked;
  const svg=graphic(root,'svg',{viewBox:`0 0 ${chartWidth} ${chartHeight}`,role:'img','aria-label':'Relative fragment intensity by mass-to-charge ratio'});
  const left=45, right=Math.max(left+1,chartWidth-22);
  const topY=showLabels?27:17, bottomY=chartHeight-(showLabels?61:49);
  const mid=a && b ? (topY+bottomY)/2 : b ? topY : bottomY;
  const max=Math.max(1,...[a,b].flatMap(spectrum => spectrum?.fragments.reduce((largest,peak) => Math.max(largest,peak[0]),0) || 0));
  const fullTick=massTick(max/5);
  const fullEnd=Math.ceil(max/fullTick)*fullTick;
  const [start,end]=mzRange || [0,fullEnd];
  const tick=massTick((end-start)/Math.max(2,Math.floor((right-left)/60)));
  mzScale={left,right,top:topY,bottom:bottomY,start,end,fullEnd};
  updateSpectrumButtons();
  const x=mz=>left+(right-left)*(mz-start)/(end-start);
  const line=(x1,y1,x2,y2,stroke,extra={})=>graphic(svg,'line',{x1,y1,x2,y2,stroke,...extra});
  const label=(x,y,value,extra={})=>graphic(svg,'text',{x,y,fill:'#4e6076','font-size':11,...extra},value);
  for (let i=Math.ceil(start/tick);i<=Math.floor(end/tick+1e-9);i++) {
    const mz=i*tick;
    line(x(mz),topY,x(mz),bottomY,'#d1dbe6');
    label(x(mz),chartHeight-27,Number(mz.toPrecision(12)),{'text-anchor':'middle'});
  }
  const extent=a && b ? (bottomY-topY)/2 : bottomY-topY;
  for (const [spectrum,sign] of [[a,-1],[b,1]]) {
    if (!spectrum) continue;
    for (const percent of [50,100]) {
      const y=mid+sign*extent*percent/100;
      line(left,y,right,y,'#d1dbe6',{'stroke-dasharray':'3 4'});
      label(left-6,y+3,percent,{'text-anchor':'end'});
    }
  }
  line(left,mid,right,mid,'#60738a');
  label(left-6,mid+3,'0',{'text-anchor':'end'});
  label((left+right)/2,chartHeight-8,'Fragment m/z',{'text-anchor':'middle'});
  const axisY=(topY+bottomY)/2;
  label(12,axisY,'Relative intensity (%)',{'text-anchor':'middle',transform:`rotate(-90 12 ${axisY})`});
  const pairs=result?.pairs || [];
  const aPairs=new Map(pairs.map(pair=>[pair.i,pair]));
  const bPairs=new Map(pairs.map(pair=>[pair.j,pair]));
  const pairPoints=[];
  for (const [spectrum,sign,color,matched] of [[a,-1,cyan,aPairs],[b,1,pink,bPairs]]) {
    if (!spectrum) continue;
    const top=spectrum.fragments.reduce((largest,peak)=>Math.max(largest,peak[1]),0);
    const annotations=[];
    spectrum.fragments.forEach(([mz,intensity],i)=>{
      if (mz<start || mz>end) return;
      const relative=intensity/top;
      const px=x(mz);
      const py=mid+sign*extent*relative;
      const pair=matched.get(i);
      const peakColor=result?(pair?(pair.shift?shiftedColor:directColor):unmatchedColor):color;
      const active=pair && pair===selectedPair;
      line(px,mid,px,py,peakColor,{'stroke-width':active?3.6:pair?2.3:1.5,'pointer-events':'none'});
      const hit=line(px,mid,px,py,'transparent',{'stroke-width':8});
      const description=pair?`${mz.toFixed(5)} m/z · ${(relative*100).toFixed(1)}% · ${pair.shift?`Shifted match, A − B ${signed(a.fragments[pair.i][0]-b.fragments[pair.j][0])} Da`:'Direct match'}`:
        `${mz.toFixed(5)} m/z · ${(relative*100).toFixed(1)}%${result?' · Unmatched':''}`;
      graphic(hit,'title',{},description);
      if (pair) hit.dataset.peakPair=pair.i;
      if (active) pairPoints.push({x:px,y:py});
      if (showLabels) annotations.push({px,py,relative,value:mz.toFixed(3),peakColor});
    });
    annotations.sort((a,b)=>b.relative-a.relative);
    const placed=[];
    for (const {px,py,value,peakColor} of annotations) {
      const half=value.length*3;
      const lx=Math.max(left+half,Math.min(chartWidth-half-3,px));
      const ly=py+(sign<0?-5:13);
      if (placed.some(box=>Math.abs(lx-box.x)<half+box.half+4 && Math.abs(ly-box.y)<12)) continue;
      placed.push({x:lx,y:ly,half});
      label(lx,ly,value,{'text-anchor':'middle',fill:peakColor,'font-size':10,'pointer-events':'none'});
    }
  }
  if (pairPoints.length===2) {
    const [top,bottom]=pairPoints;
    line(top.x,top.y,bottom.x,bottom.y,selectedPair.shift?shiftedColor:directColor,{'stroke-dasharray':'4 3','pointer-events':'none',opacity:.65});
  }
}
function showPairReadout(a,b) {
  const readout=$('pairReadout');
  readout.hidden=!selectedPair;
  if (!selectedPair) return;
  const {i,j,shift}=selectedPair;
  const mzA=a.fragments[i][0], mzB=b.fragments[j][0];
  readout.textContent=`${shift?'Shifted match':'Direct match'} · A ${mzA.toFixed(5)} · B ${mzB.toFixed(5)} · A − B ${signed(mzA-mzB)} Da`;
}
function pickPair(pair) {
  selectedPair=pair===selectedPair?null:pair;
  redrawPlot();
  for (const button of $('peakrows').querySelectorAll('.pair-button')) {
    button.setAttribute('aria-pressed',String(button.dataset.peakPair===String(selectedPair?.i)));
  }
}
function massTick(target) {
  const order=10**Math.floor(Math.log10(target));
  return [1,2,5,10].find(value=>value>=target/order-1e-10)*order;
}
function updateSpectrumButtons() {
  $('spectrumIn').disabled=!mzScale || mzScale.end-mzScale.start<=Math.min(.001,mzScale.fullEnd);
  $('spectrumOut').disabled=!mzRange;
  $('spectrumReset').disabled=!mzRange;
}
function changeMzRange(start,end) {
  const {fullEnd}=mzScale;
  const span=Math.min(fullEnd,Math.max(Math.min(.001,fullEnd),end-start));
  const left=Math.max(0,Math.min(fullEnd-span,(start+end-span)/2));
  mzRange=span>=fullEnd?null:[left,left+span];
  redrawPlot();
}
function zoomSpectrum(factor) {
  if (!mzScale) return;
  const {start,end}=mzScale;
  const center=(start+end)/2;
  const half=(end-start)*factor/2;
  changeMzRange(center-half,center+half);
}
$('spectrumIn').onclick=()=>zoomSpectrum(.5);
$('spectrumOut').onclick=()=>zoomSpectrum(2);
$('spectrumReset').onclick=()=>{
  mzRange=null;
  redrawPlot();
};
function plotPoint(event) {
  const bounds=plotRoot.getBoundingClientRect();
  return {x:event.clientX-bounds.left-plotRoot.clientLeft,y:event.clientY-bounds.top-plotRoot.clientTop};
}
plotRoot.addEventListener('pointerdown',event=>{
  if (event.button!==0 || !mzScale || mzDrag) return;
  const {x,y}=plotPoint(event);
  const {left,right,top,bottom}=mzScale;
  if (x<left || x>right || y<top || y>bottom) return;
  const band=document.createElement('div');
  band.className='mz-selection';
  band.style.top=`${top}px`;
  band.style.height=`${bottom-top}px`;
  const index=event.target.dataset?.peakPair;
  const pair=plotState.result?.pairs.find(match=>String(match.i)===index);
  mzDrag={id:event.pointerId,x,band,scale:mzScale,pair};
  plotRoot.setPointerCapture(event.pointerId);
  plotRoot.append(band);
});
plotRoot.addEventListener('pointermove',event=>{
  if (mzDrag?.id!==event.pointerId) return;
  const {x}=plotPoint(event);
  const {left,right}=mzDrag.scale;
  const end=Math.max(left,Math.min(right,x));
  mzDrag.band.style.left=`${Math.min(mzDrag.x,end)}px`;
  mzDrag.band.style.width=`${Math.abs(mzDrag.x-end)}px`;
});
plotRoot.addEventListener('lostpointercapture',event=>{
  if (mzDrag?.id!==event.pointerId) return;
  mzDrag.band.remove();
  mzDrag=null;
});
plotRoot.addEventListener('pointerup',event=>{
  if (mzDrag?.id!==event.pointerId) return;
  const {x,band,scale,pair}=mzDrag;
  mzDrag=null;
  band.remove();
  if (scale!==mzScale) return;
  const {left,right,start,end}=scale;
  const target=Math.max(left,Math.min(right,plotPoint(event).x));
  if (Math.abs(target-x)<6) {
    if (pair) pickPair(pair);
    return;
  }
  const mass=pixel=>start+(end-start)*(pixel-left)/(right-left);
  changeMzRange(mass(Math.min(x,target)),mass(Math.max(x,target)));
});
function redrawPlot() {
  if (plotState) plot(plotState.a,plotState.b,plotState.result);
}
$('plotHeight').oninput=redrawPlot;
$('peakLabels').onchange=redrawPlot;
new ResizeObserver(()=>{
  if ($('plot').clientWidth!==lastPlotWidth) redrawPlot();
}).observe($('plot'));
function showNodeMetadata(id,node) {
  const list=$(id);
  list.replaceChildren();
  list.hidden=!node;
  if (!node) return;
  const {retention,charge,precursor,libraryId,librarySpectrumId,name,inchi}=nodeMetadata(node);
  const rt=retention?`${retention.value} ${retention.unit || '(unit unspecified)'}`:'—';
  for (const [label,value] of [
    ...(name?[['Name',name]]:[]),
    ['Retention time',rt],
    ['Charge',charge || '—'],
    ['Precursor m/z',Number.isFinite(precursor)?precursor.toFixed(5):'—'],
    ['Library ID',libraryId || '—'],
    ...(librarySpectrumId && librarySpectrumId!==libraryId?[['Library spectrum ID',librarySpectrumId]]:[]),
    ...(inchi?[['InChI',inchi]]:[])
  ]) {
    const row=document.createElement('div');
    const term=document.createElement('dt');
    term.textContent=label;
    const detail=document.createElement('dd');
    detail.textContent=value;
    if (label==='InChI') row.className='inchi-detail';
    row.append(term,detail);
    list.append(row);
  }
  if (inchi) {
    const row=document.createElement('div');
    row.className='structure-detail';
    const term=document.createElement('dt'), detail=document.createElement('dd');
    term.textContent='Structure';
    row.append(term,detail);
    list.append(row);
    showInchiStructure(detail,inchi);
  }
}
function updateAnnotationButtons() {
  for (const [side,member] of [['A',first],['B',second]]) {
    const button=$(`annotate${side}`);
    button.hidden=!member;
    button.onclick=()=>annotateNode(member);
  }
}
function inspect() {
  showNodeMetadata('metaA',first);
  showNodeMetadata('metaB',second);
  updateAnnotationButtons();
  const a=first?.spectrum, b=second?.spectrum;
  const tolerance=Number($('tolerance').value);
  const valid=$('tolerance').checkValidity() && tolerance>0;
  const shifted=$('mode').value==='shift';
  const delta=a && b?a.precursor-b.precursor:NaN;
  const result=a && b && valid?align(a,b,tolerance,shifted):null;
  const missing=[first,second].filter(node=>node && !node.spectrum);
  const notes=missing.length && (a || b) ? [`No fragmentation peaks for ${missing.map(title).join(' or ')}.`] : [];
  if (!a || !b) notes.push('Select two nodes with fragmentation spectra to align them.');
  if (!valid) notes.push('Enter a peak tolerance from 0.0001 to 100 Da.');
  if (a && b && shifted && !Number.isFinite(delta)) notes.push('Direct matching is used until both precursor masses are available.');
  $('spectrumNote').textContent=notes.join(' ');
  $('spectrumNote').hidden=!notes.length;
  $('score').textContent=result?result.score.toFixed(3):'—';
  const shiftedCount=result?.pairs.filter(pair=>pair.shift!==0).length;
  $('matches').textContent=result?`${result.pairs.length} (${shiftedCount} shifted)`:'—';
  $('delta').textContent=Number.isFinite(delta)?`${delta.toFixed(4)} Da`:'—';
  plot(a,b,result);
  const rows=$('peakrows');
  rows.replaceChildren();
  if (!result?.pairs.length) { rows.textContent=result?'No peaks matched at this tolerance.':'Choose two spectra to see matched peaks.'; return; }
  const table = rows.appendChild(document.createElement('table'));
  const heading = table.createTHead().insertRow();
  for (const name of ['A m/z','B m/z','A − B (Da)','Match','Error (Da)']) {
    const cell=document.createElement('th');
    cell.scope='col'; cell.textContent=name; heading.append(cell);
  }
  const body=table.createTBody();
  for (const pair of result.pairs.sort((p,q)=>a.fragments[p.i][0]-a.fragments[q.i][0])) {
    const row=body.insertRow();
    const mzA=a.fragments[pair.i][0], mzB=b.fragments[pair.j][0];
    for (const value of [mzA,mzB]) row.insertCell().textContent=value.toFixed(5);
    row.insertCell().textContent=signed(mzA-mzB);
    const button=document.createElement('button');
    button.className=pair.shift?'pair-button shifted':'pair-button';
    button.dataset.peakPair=pair.i;
    button.setAttribute('aria-pressed','false');
    button.textContent=pair.shift?'Shifted':'Direct';
    button.onclick=()=>pickPair(pair);
    row.insertCell().append(button);
    row.insertCell().textContent=pair.error.toFixed(5);
  }
}
function select(a,b) {
  first=a; second=b===a?null:b;
  $('a').value=first?.id || ''; $('b').value=second?.id || '';
  inspect(); draw();
}
$('a').onchange=()=>select(byId.get($('a').value),second);
$('b').onchange=()=>{
  const node=byId.get($('b').value);
  select(node===first?second:first,node);
};
$('mode').onchange=inspect;
$('tolerance').oninput=inspect;
$('search').oninput=()=>{
  const query=$('search').value.trim().toLowerCase();
  const results=$('results');
  results.replaceChildren(); results.hidden=!query;
  if (!query) return;
  const matches=nodes.filter(node=>[node.id,node.label,node.scan].some(value=>value.toLowerCase().includes(query))).slice(0,30);
  if (!matches.length) results.textContent='No matching nodes';
  for (const node of matches) {
    const button=document.createElement('button');
    button.textContent=title(node);
    button.onclick=()=>{
      view.x=width/2-node.x*view.k; view.y=height/2-node.y*view.k;
      select(node,second); $('search').value=''; results.hidden=true;
    };
    results.append(button);
  }
};
$('search').onkeydown=event=>{
  if (event.key==='Escape') $('results').hidden=true;
  if (event.key==='Enter' && !$('results').hidden) $('results').querySelector('button')?.click();
};

function attachSpectra() {
  const register = (map,key,spectrum) => {
    if (!key) return;
    map.set(key,map.has(key)?null:spectrum);
  };
  const scans = new Map(), titles = new Map();
  for (const spectrum of imported) {
    register(scans,spectrum.scan,spectrum);
    register(titles,spectrum.title,spectrum);
  }
  let matched=0, available=0;
  for (const node of nodes) {
    const external=scans.get(node.scan) || scans.get(node.id) || titles.get(node.scan) || titles.get(node.id);
    if (external) {
      matched++;
      node.spectrum={fragments:external.fragments,metadata:external.metadata,precursor:Number.isFinite(external.precursor)?external.precursor:node.precursor};
    } else node.spectrum=node.fragments.length?node:undefined;
    if (node.spectrum) available++;
  }
  $('counts').textContent=`${nodes.length.toLocaleString()} nodes · ${edges.length.toLocaleString()} edges · ${available.toLocaleString()} spectra`;
  updateLabelFields();
  return matched;
}
function updateLabelFields() {
  const select=$('nodeLabel');
  const previous=select.selectedIndex<0?'mass':select.value;
  const graphFields=new Set();
  const mgfFields=new Set();
  for (const node of nodes) {
    for (const [field,value] of node.fields || []) {
      if (value && field) graphFields.add(field);
    }
    for (const field of Object.keys(node.spectrum?.metadata || {})) mgfFields.add(field);
  }
  select.replaceChildren(new Option('Selected nodes only',''),new Option('Node ID','id'),new Option('Node name','name'),new Option('Parent mass (m/z)','mass'));
  for (const [label,prefix,fields] of [['GraphML fields','graph:',graphFields],['MGF headers','mgf:',mgfFields]]) {
    if (!fields.size) continue;
    const group=document.createElement('optgroup');
    group.label=label;
    for (const field of [...fields].sort((a,b)=>a.localeCompare(b))) group.append(new Option(field,prefix+field));
    select.append(group);
  }
  select.value=[...select.options].some(option=>option.value===previous)?previous:'mass';
}
$('nodeLabel').onchange=draw;

function openColorColumns(network,retain=false) {
  const select=$('colorBy');
  const previous=retain && select.value!==''?colorColumns[Number(select.value)]?.id:undefined;
  colorColumns=[...network.columns.values()];
  select.replaceChildren(new Option('Network families',''));
  for (const [index,column] of colorColumns.entries()) select.append(new Option(column.name,String(index)));
  select.disabled=!colorColumns.length;
  const index=colorColumns.findIndex(column=>column.id===previous);
  if (index>=0) select.value=String(index);
  if (!retain) $('colorLegend').open=false;
  updateColors();
}
function updateColors() {
  const choice=$('colorBy').value;
  const column=choice===''?null:colorColumns[Number(choice)];
  const legendPanel=$('colorLegend');
  const entries=$('colorEntries');
  entries.replaceChildren();
  legendPanel.hidden=!column;
  if (!column) {
    nodeColors=new Map();
    return;
  }
  const {colors,legend}=nodeColorMap(nodes,column);
  nodeColors=colors;
  for (const [value,{color,count}] of [...legend].slice(0,100)) {
    const item=document.createElement('li');
    const swatch=document.createElement('i');
    swatch.style.backgroundColor=color;
    swatch.setAttribute('aria-hidden','true');
    const name=document.createElement('span');
    name.textContent=value || 'Missing value';
    const total=document.createElement('span');
    total.textContent=count.toLocaleString();
    item.append(swatch,name,total);
    entries.append(item);
  }
  if (legend.size>100) {
    const more=document.createElement('li');
    more.textContent=`${legend.size-100} more values`;
    entries.append(more);
  }
}
$('colorBy').onchange=()=>{
  updateColors();
  draw();
};
function updateSpectrumOptions() {
  for (const id of ['a','b']) {
    const fragment=document.createDocumentFragment();
    fragment.append(new Option('Select a node',''));
    for (const node of nodes) fragment.append(new Option(title(node),node.id));
    $(id).replaceChildren(fragment);
  }
}
function load(network,name,isDemo=false) {
  group.clear();
  setBoxMode(false);
  nodes=network.nodes;
  byId=new Map(nodes.map(node=>[node.id,node]));
  edges=network.edges.map(([a,b])=>[byId.get(a),byId.get(b)]);
  layout();
  attachSpectra();
  openColorColumns(network);
  updateSpectrumOptions();
  openNodeTable(network,name,()=>{
    attachSpectra();
    if (network.columns.size!==colorColumns.length) openColorColumns(network,true);
    else updateColors();
    updateSpectrumOptions();
    select(first,second);
  });
  $('filename').textContent=name;
  $('search').value='';
  $('results').hidden=true;
  hover=null;
  const pair=isDemo?(edges.find(edge=>edge.every(node=>node.spectrum && nodeMetadata(node).libraryId)) ||
    edges.find(edge=>edge.every(node=>node.spectrum))):null;
  const initial=nodes.find(node=>node.spectrum) || nodes[0];
  select(pair?.[0] || initial,pair?.[1] || null);
  fit();
}
function loadDemo() {
  ++importGeneration;
  const files=exampleFiles();
  const network=graphml(files.graph);
  imported=mgf(files.spectra);
  usingExampleSpectra=true;
  load(network,'Synthetic example network',true);
  $('status').textContent='Synthetic example data · Shift-click a node to compare it with spectrum A.';
}
$('demo').onclick=loadDemo;
$('graphml').onclick=()=>$('graphfile').click();
$('mgf').onclick=()=>$('spectrafile').click();
$('graphfile').onchange=async event=>{
  const [file]=event.target.files;
  event.target.value='';
  if (!file) return;
  try {
    const network=graphml(await file.text());
    ++importGeneration;
    if (usingExampleSpectra) imported=[];
    usingExampleSpectra=false;
    load(network,file.name);
    const matched=attachSpectra();
    $('status').textContent=imported.length?`GraphML loaded. ${matched} nodes linked to imported spectra.`:'GraphML loaded. Use Import MGF to link spectra by scan or node ID.';
  } catch(error) { $('status').textContent=error.message; }
};
$('spectrafile').onchange=async event=>{
  const files=[...event.target.files];
  event.target.value='';
  if (!files.length) return;
  const generation=importGeneration;
  try {
    const spectra=(await Promise.all(files.map(async file=>mgf(await file.text())))).flat();
    if (generation!==importGeneration) return;
    if (!spectra.length) throw Error('No readable MGF spectra were found.');
    imported=spectra;
    usingExampleSpectra=false;
    const linked=attachSpectra();
    $('status').textContent=`Read ${spectra.length} spectra from ${files.length} MGF file(s). Linked ${linked} of ${nodes.length} nodes.${linked?'':' Check that MGF SCANS values match GraphML scan or node IDs.'}`;
    inspect();
    draw();
  } catch(error) { $('status').textContent=error.message; }
};
loadDemo();
