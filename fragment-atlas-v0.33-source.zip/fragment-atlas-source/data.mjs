const number = value => value?.trim() ? Number(value) : NaN;
const normalized = key => key.toLowerCase().replace(/[^a-z0-9]/g, '');
const peaks = input => input.filter(([mz, intensity]) => Number.isFinite(mz) && Number.isFinite(intensity) && mz > 0 && intensity > 0);
function embedded(value) {
  try {
    const data = JSON.parse(value);
    if (Array.isArray(data) && data.every(Array.isArray)) return peaks(data.map(pair => pair.map(Number)));
  } catch {}
  return peaks(value.trim().split(/[;\n]+/).map(line => line.trim().split(/[\s,:]+/).map(Number)).filter(pair => pair.length === 2));
}
const elements = (item, name) => [...item.getElementsByTagNameNS('*', name)];
export function graphml(source) {
  const xml = new DOMParser().parseFromString(source, 'application/xml');
  if (xml.documentElement.localName !== 'graphml' || elements(xml,'parsererror').length) throw Error('Invalid GraphML document.');
  const columns = new Map();
  for (const key of elements(xml,'key')) {
    const id=key.getAttribute('id');
    const scope=key.getAttribute('for');
    if (!id || (scope && scope!=='node' && scope!=='all')) continue;
    const fallback=[...key.children].find(child=>child.localName==='default' && !child.children.length);
    columns.set(id,{id,name:key.getAttribute('attr.name') || id,type:key.getAttribute('attr.type') || 'string',fallback:fallback?.textContent ?? ''});
  }
  const nodes = elements(xml,'node').map(item => {
    const id=item.getAttribute('id');
    const values=new Map();
    for (const child of item.children) {
      if (child.localName!=='data' || (child.namespaceURI && child.namespaceURI!==item.namespaceURI)) continue;
      const key=child.getAttribute('key');
      if (!key) continue;
      if (!columns.has(key)) columns.set(key,{id:key,name:key,type:'string',fallback:''});
      values.set(key,child);
    }
    return {id,element:item,values};
  });
  const defaults=[...columns.values()].filter(column=>column.fallback);
  for (const node of nodes) readNodeFields(node,columns,defaults);
  if (!nodes.length) throw Error('This GraphML file contains no nodes.');
  const ids = new Set(nodes.map(node => node.id));
  if (ids.size !== nodes.length || ids.has(null) || ids.has('')) throw Error('GraphML nodes must have unique IDs.');
  const edges = elements(xml,'edge').map(item => [item.getAttribute('source'),item.getAttribute('target')]).filter(edge => edge.every(id => ids.has(id)));
  return {nodes,edges,xml,columns,defaults};
}

function readNodeFields(node,columns,defaults) {
  const fields=new Map();
  for (const [key,value] of node.values) {
    if (!value.children.length) fields.set(columns.get(key).name,value.textContent.trim());
  }
  for (const column of defaults) {
    if (!node.values.has(column.id) && !fields.has(column.name)) fields.set(column.name,column.fallback.trim());
  }
  const data=new Map([...fields].map(([key,value])=>[normalized(key),value]));
  const get=(...names)=>names.map(name=>data.get(name)).find(Boolean);
  node.fields=fields;
  node.label=get('compoundname','annotation','label','name') || node.id;
  node.scan=get('clusterindex','scans','scan','scanid','rowid','featureid','sharedname') || node.id;
  node.precursor=number(get('precursormz','precursormass','parentmass','parentmz','pepmass','mz','mass'));
  node.fragments=embedded(get('peaks','spectrum','fragmentation','msmspeaks','spectrumpeaks') || '');
}
export function addStringColumn(network,name,preferredId) {
  const root=network.xml.documentElement;
  const existing=new Set(elements(root,'key').map(key=>key.getAttribute('id')));
  let id=preferredId;
  for (let i=2;existing.has(id) || network.columns.has(id);i++) id=`${preferredId}${i}`;
  const graph=[...root.children].find(child=>child.localName==='graph');
  const template=[...root.children].find(child=>child.localName==='key') || graph || root;
  const key=network.xml.createElementNS(template.namespaceURI,template.prefix?`${template.prefix}:key`:'key');
  for (const [attribute,value] of [['id',id],['for','node'],['attr.name',name],['attr.type','string']]) key.setAttribute(attribute,value);
  root.insertBefore(key,graph || null);
  const column={id,name,type:'string',fallback:''};
  network.columns.set(id,column);
  return column;
}

export function validateGraphmlText(value) {
  if (/[^\u0009\u000a\u000d\u0020-\ud7ff\ue000-\ufffd\u{10000}-\u{10ffff}]/u.test(value)) throw Error('This value contains characters that GraphML cannot store.');
}

export function setGraphmlValue(network,node,column,value) {
  let element=node.values.get(column.id);
  if (element?.children.length) throw Error('Structured XML attributes are read-only.');
  const trimmed=value.trim();
  validateGraphmlText(value);
  if (trimmed) {
    const type=column.type.toLowerCase();
    if (type==='boolean' && !/^(true|false|0|1)$/.test(trimmed)) throw Error('Enter true, false, 1, or 0.');
    if (type==='int' || type==='long') {
      if (!/^[+-]?\d+$/.test(trimmed)) throw Error('Enter a whole number.');
      const limit=type==='int'?2147483648n:9223372036854775808n;
      const integer=BigInt(trimmed);
      if (integer < -limit || integer >= limit) throw Error('This number is outside the range for this field.');
    }
    if ((type==='float' || type==='double') && !/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(trimmed)) throw Error('Enter a decimal number.');
  }
  if (!value || (column.type!=='string' && !trimmed)) {
    element?.remove();
    node.values.delete(column.id);
  } else {
    if (!element) {
      const prefix=node.element.prefix;
      element=network.xml.createElementNS(node.element.namespaceURI,prefix?`${prefix}:data`:'data');
      element.setAttribute('key',column.id);
      const nested=[...node.element.children].find(child=>child.localName==='graph');
      node.element.insertBefore(element,nested || null);
      node.values.set(column.id,element);
    }
    element.textContent=value;
  }
  readNodeFields(node,network.columns,network.defaults);
}

export function mgf(source) {
  const spectra = [];
  let current;
  for (const entry of source.split(/\r?\n/)) {
    const line = entry.trim();
    if (/^BEGIN IONS$/i.test(line)) current = {metadata:{},fragments:[]};
    else if (current && /^END IONS$/i.test(line)) {
      const {metadata} = current;
      current.fragments = peaks(current.fragments);
      current.precursor = number(metadata.PEPMASS?.split(/[\s,]+/)[0]);
      current.scan = metadata.SCANS || metadata.FEATURE_ID;
      current.title = metadata.TITLE;
      if (current.fragments.length) spectra.push(current);
      current = undefined;
    } else if (current && /^[\w]+\s*=/.test(line)) {
      const equals = line.indexOf('=');
      current.metadata[line.slice(0,equals).trim().toUpperCase()] = line.slice(equals+1).trim();
    } else if (current && /^\d|^\.\d/.test(line)) {
      current.fragments.push(line.split(/\s+/).slice(0,2).map(Number));
    }
  }
  return spectra;
}

const timePrefixes=['rt','rtmean','retentiontime','averagert','averageretentiontime','rowretentiontime','featureretentiontime'];
const timeUnits=[
  ['min',['min','mins','minute','minutes']],
  ['s',['s','sec','secs','second','seconds']]
];

export function nodeMetadata(node) {
  if (!node) return null;
  const fields=new Map([...(node.fields || [])].map(([name,value])=>[normalized(name),value]));
  const get=keys=>keys.map(key=>fields.get(key)).find(value=>value?.trim());
  const mgf=node.spectrum?.metadata;
  let retention;
  for (const [unit,suffixes] of timeUnits) {
    const value=get(timePrefixes.flatMap(prefix=>suffixes.map(suffix=>prefix+suffix))) ||
      get(timePrefixes.flatMap(prefix=>suffixes.map(suffix=>prefix+suffix+'mean')));
    if (value) {
      retention={value,unit};
      break;
    }
  }
  if (!retention && mgf?.RTINSECONDS?.trim()) retention={value:mgf.RTINSECONDS,unit:'s'};
  if (!retention && mgf?.RTINMINUTES?.trim()) retention={value:mgf.RTINMINUTES,unit:'min'};
  if (!retention) {
    const value=get(timePrefixes);
    if (value) {
      const embeddedUnit=value.match(/\s*(minutes?|mins?|seconds?|secs?|s)\s*$/i);
      const fieldUnit=get(['rtunit','rtunits','retentiontimeunit','retentiontimeunits']);
      const unitText=(embeddedUnit?.[1] || fieldUnit || '').trim().toLowerCase();
      const unit=timeUnits.find(([,names])=>names.includes(unitText))?.[0];
      retention={value:embeddedUnit && unit?value.slice(0,embeddedUnit.index).trim():value,unit};
    }
  }
  const charge=get(['precursorcharge','charge','chargestate','ioncharge','rowcharge']) || mgf?.CHARGE;
  const precursor=Number.isFinite(node.spectrum?.precursor)?node.spectrum.precursor:node.precursor;
  const meaningful=value=>value && !/^(?:n\/?a|none|null|unknown|-)$/i.test(value.trim())?value.trim():undefined;
  const libraryId=meaningful(get(['libraryid','gnpslibraryid'])) || meaningful(mgf?.LIBRARYID);
  const librarySpectrumId=meaningful(get(['libraryspectrumid','spectrumid'])) || meaningful(mgf?.LIBRARYSPECTRUMID) || meaningful(mgf?.SPECTRUMID);
  const name=meaningful(get(['compoundname','annotation','label'])) || (node.label!==node.id?meaningful(node.label):undefined);
  const inchi=meaningful(get(['inchi','standardinchi','stdinchi'])) || meaningful(mgf?.INCHI);
  return {retention,charge,precursor,libraryId,librarySpectrumId,name,inchi};
}

const categoryColors=[
  '#2464ac','#c46016','#26846d','#8953a7','#ae425d','#677d23',
  '#147e9b','#a37516','#4c58a7','#9d4f8b','#965d3b','#39885b'
];

export function nodeColorMap(nodes,column) {
  const colors=new Map();
  const counts=new Map();
  for (const node of nodes) {
    const element=node.values?.get(column.id);
    const value=element?.children.length?'':element?.textContent ?? column.fallback;
    const key=value?.trim() || '';
    colors.set(node,key);
    counts.set(key,(counts.get(key) || 0)+1);
  }
  const values=[...counts.keys()].filter(Boolean).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
  const explicit=values.every(value=>/^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(value));
  const legend=new Map(values.map((value,i)=>{
    const color=explicit?value:categoryColors[i] || `hsl(${Math.round(i*137.508)%360} 57% ${i%2?42:54}%)`;
    return [value,{color,count:counts.get(value)}];
  }));
  if (counts.has('')) legend.set('',{color:'#aab4c1',count:counts.get('')});
  for (const [node,key] of colors) colors.set(node,legend.get(key).color);
  return {colors,legend};
}

export function align(a,b,tolerance,useShift) {
  const delta = a.precursor - b.precursor;
  const candidates = [];
  const sorted = b.fragments.map(([mz,intensity],j) => ({mz,intensity,j})).sort((left,right) => left.mz-right.mz);
  const scaleA = a.fragments.reduce((max, peak) => Math.max(max,peak[1]), 0) || 1;
  const scaleB = b.fragments.reduce((max, peak) => Math.max(max,peak[1]), 0) || 1;
  const shifts = useShift && Number.isFinite(delta) && delta !== 0 ? [0,delta] : [0];
  a.fragments.forEach(([mz,intensity],i) => {
    for (const shift of shifts) {
      const lower = mz-shift-tolerance;
      let start = 0;
      let end = sorted.length;
      while (start < end) {
        const middle = Math.floor((start+end)/2);
        if (sorted[middle].mz < lower) start = middle+1;
        else end = middle;
      }
      for (let k=start; k<sorted.length && sorted[k].mz<=mz-shift+tolerance; k++) {
        const other = sorted[k];
        candidates.push({i,j:other.j,shift,error:Math.abs(mz-other.mz-shift),weight:(intensity/scaleA)*(other.intensity/scaleB)});
      }
    }
  });
  candidates.sort((left,right) => right.weight-left.weight || left.error-right.error || Math.abs(left.shift)-Math.abs(right.shift));
  const usedA = new Set();
  const usedB = new Set();
  const pairs = [];
  let dot = 0;
  for (const pair of candidates) {
    if (usedA.has(pair.i) || usedB.has(pair.j)) continue;
    usedA.add(pair.i);
    usedB.add(pair.j);
    dot += pair.weight;
    pairs.push(pair);
  }
  const norm = (spectrum,scale) => Math.sqrt(spectrum.fragments.reduce((sum,peak) => sum+(peak[1]/scale)**2,0));
  return {pairs,usedA,usedB,score:Math.min(1,dot/(norm(a,scaleA)*norm(b,scaleB) || 1))};
}
