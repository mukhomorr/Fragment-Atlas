const gap=54;
const cell=64;
const palette=['#4184ae','#7659a8','#318979','#3570ae','#a15082','#a56b34'];

function arrangeComponent(group,links,color) {
  const count=group.length;
  const columns=Math.ceil(Math.sqrt(count));
  group.forEach((node,i)=>{
    node.x=(i%columns)*gap+Math.sin(i*2.39996)*12;
    node.y=Math.floor(i/columns)*gap+Math.cos(i*2.39996)*12;
    node.color=color;
  });
  if (count===1) return {left:0,top:12,width:0,height:0};
  const iterations=count>2000?30:count>500?52:96;
  const forces=new Map(group.map(node=>[node,{x:0,y:0}]));
  for (let step=0;step<iterations;step++) {
    const grid=new Map();
    for (const node of group) {
      const cx=Math.floor(node.x/cell), cy=Math.floor(node.y/cell);
      const force=forces.get(node);
      force.x=0; force.y=0;
      for (let y=cy-1;y<=cy+1;y++) for (let x=cx-1;x<=cx+1;x++) {
        for (const other of grid.get(`${x}:${y}`) || []) {
          const dx=node.x-other.x, dy=node.y-other.y;
          const distance=Math.hypot(dx,dy) || .001;
          if (distance>=cell) continue;
          const strength=(cell-distance)*.30/distance;
          const fx=(dx || (dy?0:.001))*strength, fy=dy*strength;
          force.x+=fx; force.y+=fy;
          const target=forces.get(other);
          target.x-=fx; target.y-=fy;
        }
      }
      const key=`${cx}:${cy}`;
      if (!grid.has(key)) grid.set(key,[]);
      grid.get(key).push(node);
    }
    for (const [a,b] of links) {
      const dx=b.x-a.x, dy=b.y-a.y;
      const distance=Math.hypot(dx,dy) || 1;
      const strength=(distance-gap)*.13/distance;
      const fa=forces.get(a), fb=forces.get(b);
      fa.x+=dx*strength; fa.y+=dy*strength;
      fb.x-=dx*strength; fb.y-=dy*strength;
    }
    const limit=12*(1-step/iterations)+.5;
    for (const node of group) {
      const force=forces.get(node);
      const factor=Math.min(1,limit/(Math.hypot(force.x,force.y) || 1));
      node.x+=force.x*factor; node.y+=force.y*factor;
    }
  }
  let left=Infinity,top=Infinity,right=-Infinity,bottom=-Infinity;
  for (const node of group) {
    left=Math.min(left,node.x); top=Math.min(top,node.y);
    right=Math.max(right,node.x); bottom=Math.max(bottom,node.y);
  }
  return {left,top,width:right-left,height:bottom-top};
}

export function arrangeNetwork(nodes,edges,aspect=1.4) {
  const neighbors=new Map(nodes.map(node=>[node,[]]));
  for (const [a,b] of edges) {
    if (a===b) continue;
    neighbors.get(a).push(b);
    neighbors.get(b).push(a);
  }
  const order=[...nodes].sort((a,b)=>neighbors.get(b).length-neighbors.get(a).length);
  const owner=new Map();
  const groups=[];
  for (const root of order) {
    if (owner.has(root)) continue;
    const component={nodes:[root],links:[]};
    groups.push(component);
    owner.set(root,component);
    for (const node of component.nodes) {
      for (const neighbor of neighbors.get(node)) {
        if (owner.has(neighbor)) continue;
        owner.set(neighbor,component);
        component.nodes.push(neighbor);
      }
    }
  }
  for (const edge of edges) {
    if (edge[0]!==edge[1]) owner.get(edge[0]).links.push(edge);
  }
  const pad=42;
  let area=0,maxWidth=0;
  groups.sort((a,b)=>b.nodes.length-a.nodes.length);
  groups.forEach((group,i)=>{
    group.bounds=arrangeComponent(group.nodes,group.links,group.nodes.length===1?'#8896a6':palette[i%palette.length]);
    group.width=group.bounds.width+pad;
    group.height=group.bounds.height+pad;
    area+=group.width*group.height;
    maxWidth=Math.max(maxWidth,group.width);
  });
  const limit=Math.max(maxWidth,Math.sqrt(area*Math.max(.65,Math.min(2.4,aspect))));
  let x=0,y=0,row=0;
  for (const group of groups) {
    if (x && x+group.width>limit) { x=0; y+=row; row=0; }
    for (const node of group.nodes) {
      node.x+=x-group.bounds.left+pad/2;
      node.y+=y-group.bounds.top+pad/2;
    }
    x+=group.width;
    row=Math.max(row,group.height);
  }
}
