import {addStringColumn,setGraphmlValue,validateGraphmlText} from './data.mjs';

const $=id=>document.getElementById(id);
const workspace=document.querySelector('.workspace');
const divider=$('paneDivider');
let paneWidth=43;
let resizePointer=null;

function setPaneWidth(value) {
  paneWidth=Math.max(30,Math.min(70,Math.round(value)));
  workspace.style.setProperty('--spectrum-width',`${paneWidth}%`);
  divider.setAttribute('aria-valuenow',paneWidth);
}
divider.addEventListener('pointerdown',event=>{
  if (event.button!==0 || resizePointer!==null) return;
  resizePointer=event.pointerId;
  divider.setPointerCapture(event.pointerId);
});
divider.addEventListener('pointermove',event=>{
  if (event.pointerId!==resizePointer) return;
  const bounds=workspace.getBoundingClientRect();
  setPaneWidth((bounds.right-event.clientX-8)*100/bounds.width);
});
divider.addEventListener('lostpointercapture',()=>{ resizePointer=null; });
divider.addEventListener('keydown',event=>{
  if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
  event.preventDefault();
  const value={ArrowLeft:paneWidth+3,ArrowRight:paneWidth-3,Home:30,End:70}[event.key];
  setPaneWidth(value);
});
divider.addEventListener('dblclick',()=>setPaneWidth(43));

let activeNetwork=null;
let filename='';
let notify;
let offset=0;
let edited=0;
const pageSize=25;
const tableSearch=$('tableSearch');

export function openNodeTable(network,name,onEdit) {
  activeNetwork=network.xml?network:null;
  filename=name;
  notify=onEdit;
  offset=0;
  edited=0;
  tableSearch.value='';
  $('tableControls').hidden=!activeNetwork;
  $('exportGraph').disabled=!activeNetwork;
  $('tableStatus').textContent=activeNetwork?'Edit node attributes, then export a GraphML copy.':'Open a GraphML file to edit its node attributes.';
  renderTable();
}

const annotationDialog=$('annotationDialog');
const annotationFields=[
  {name:'Compound name',id:'compoundName',keys:['compoundname','annotation','label','name']},
  {name:'InChI',id:'INCHI',keys:['inchi','standardinchi','stdinchi'],long:true},
  {name:'SMILES',id:'Smiles',keys:['smiles','canonicalsmiles','isomericsmiles'],long:true},
  {name:'Library ID',id:'LibraryID',keys:['libraryid','gnpslibraryid']},
  {name:'Library spectrum ID',id:'SpectrumID',keys:['libraryspectrumid','spectrumid']},
  {name:'Annotation notes',id:'annotationNotes',keys:['annotationnotes','notes'],long:true}
];
let editingNode=null, inputs=[];

function annotationColumn(node,field) {
  const columns=[...activeNetwork.columns.values()];
  for (const key of field.keys) {
    const column=columns.find(candidate=>{
      if (candidate.type.toLowerCase()!=='string' || candidate.name.toLowerCase().replace(/[^a-z0-9]/g,'')!==key) return false;
      const data=node.values.get(candidate.id);
      if (data?.children.length) return false;
      return key!=='name' || !/^\d+$/.test(data?.textContent.trim() || '') && data?.textContent.trim()!==node.id;
    });
    if (column) return column;
  }
}
export function annotateNode(node) {
  if (!activeNetwork || !node) return;
  editingNode=node;
  $('annotationTitle').textContent=`Annotate node ${node.id}`;
  $('annotationStatus').textContent='';
  const fields=$('annotationFields');
  fields.replaceChildren();
  inputs=annotationFields.map(field=>{
    const column=annotationColumn(node,field);
    const value=column?(node.values.get(column.id)?.textContent ?? column.fallback):'';
    const initial=/^(?:n\/?a|none|null|unknown|-)$/i.test(value.trim())?'':value;
    const label=document.createElement('label');
    label.textContent=field.name;
    const input=document.createElement(field.long?'textarea':'input');
    if (field.long) input.rows=2;
    input.maxLength=32000;
    input.value=initial;
    label.append(input);
    fields.append(label);
    return {field,column,input,initial};
  });
  annotationDialog.showModal();
  inputs[0].input.focus();
}
$('closeAnnotation').onclick=()=>annotationDialog.close();
$('cancelAnnotation').onclick=()=>annotationDialog.close();
$('annotationForm').onsubmit=event=>{
  event.preventDefault();
  const changes=inputs.filter(({input,initial})=>input.value!==initial);
  try {
    for (const {input,field} of changes) {
      validateGraphmlText(input.value);
      if (field.id==='INCHI' && input.value.trim() && !/^InChI=1S?\/\S+$/.test(input.value.trim())) throw Error('Enter a complete InChI starting with InChI=1/ or InChI=1S/.');
    }
    for (const {field,column,input} of changes) {
      const value=input.value.trim();
      if (!column && !value) continue;
      const destination=column || addStringColumn(activeNetwork,field.name,field.id);
      setGraphmlValue(activeNetwork,editingNode,destination,value);
    }
  } catch(error) {
    $('annotationStatus').textContent=error.message;
    return;
  }
  annotationDialog.close();
  if (changes.length) {
    recordEdit();
    renderTable();
  }
};
function recordEdit() {
  edited++;
  $('tableStatus').textContent=`${edited} ${edited===1?'edit':'edits'} in this session. Export GraphML to keep a copy.`;
  notify();
}

function renderTable() {
  const container=$('nodeTable');
  container.replaceChildren();
  if (!activeNetwork) return;
  const query=tableSearch.value.trim().toLowerCase();
  const {nodes,columns}=activeNetwork;
  const rows=query?nodes.filter(node=>node.id.toLowerCase().includes(query) || [...node.fields.values()].some(value=>value.toLowerCase().includes(query))):nodes;
  offset=Math.min(offset,Math.max(0,Math.ceil(rows.length/pageSize)-1)*pageSize);
  $('rowCount').textContent=rows.length?`${offset+1}–${Math.min(offset+pageSize,rows.length)} of ${rows.length}`:'No matching rows';
  $('prevRows').disabled=offset===0;
  $('nextRows').disabled=offset+pageSize>=rows.length;
  if (!rows.length) return;
  const table=container.appendChild(document.createElement('table'));
  const heading=table.createTHead().insertRow();
  for (const name of ['Node ID',...[...columns.values()].map(column=>column.name)]) {
    const cell=document.createElement('th');
    cell.scope='col';
    cell.textContent=name;
    heading.append(cell);
  }
  const body=table.createTBody();
  for (const node of rows.slice(offset,offset+pageSize)) {
    const row=body.insertRow();
    row.insertCell().textContent=node.id;
    for (const column of columns.values()) {
      const data=node.values.get(column.id);
      const cell=row.insertCell();
      if (data?.children.length) {
        cell.textContent='Structured XML';
        continue;
      }
      const value=data?.textContent || '';
      const input=document.createElement(/[\r\n]/.test(value)?'textarea':'input');
      input.value=value;
      input.placeholder=column.fallback;
      input.setAttribute('aria-label',`${column.name}, node ${node.id}`);
      input.addEventListener('change',()=>{
        try {
          setGraphmlValue(activeNetwork,node,column,input.value);
          input.value=node.values.get(column.id)?.textContent || '';
        } catch (error) {
          input.value=node.values.get(column.id)?.textContent || '';
          $('tableStatus').textContent=`${column.name}, node ${node.id}. ${error.message} The previous value was kept.`;
          return;
        }
        recordEdit();
      });
      if (input.tagName==='INPUT') input.addEventListener('keydown',event=>{
        if (event.key==='Enter') input.blur();
      });
      cell.append(input);
    }
  }
}
tableSearch.addEventListener('input',()=>{ offset=0; renderTable(); });
$('prevRows').onclick=()=>{ offset-=pageSize; renderTable(); };
$('nextRows').onclick=()=>{ offset+=pageSize; renderTable(); };
$('exportGraph').onclick=()=>{
  if (!activeNetwork) return;
  const xml=new XMLSerializer().serializeToString(activeNetwork.xml);
  const url=URL.createObjectURL(new Blob([xml],{type:'application/graphml+xml'}));
  const link=document.createElement('a');
  link.href=url;
  link.download=`${filename.replace(/\.(graphml|xml)$/i,'')}-edited.graphml`;
  link.click();
  setTimeout(()=>URL.revokeObjectURL(url),30000);
};
